﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOrder
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.radAmericano = New System.Windows.Forms.RadioButton
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.radMocha = New System.Windows.Forms.RadioButton
        Me.radLatte = New System.Windows.Forms.RadioButton
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.radVeinti = New System.Windows.Forms.RadioButton
        Me.radGrande = New System.Windows.Forms.RadioButton
        Me.radTall = New System.Windows.Forms.RadioButton
        Me.lbxMilk = New System.Windows.Forms.ListBox
        Me.lbExtraShots = New System.Windows.Forms.Label
        Me.cbxVanilla = New System.Windows.Forms.CheckBox
        Me.cbxAlmond = New System.Windows.Forms.CheckBox
        Me.cbxCaramel = New System.Windows.Forms.CheckBox
        Me.gbxFlavors = New System.Windows.Forms.GroupBox
        Me.txtShots = New System.Windows.Forms.TextBox
        Me.lblOrder = New System.Windows.Forms.Label
        Me.btnOrder = New System.Windows.Forms.Button
        Me.btnClear = New System.Windows.Forms.Button
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.gbxFlavors.SuspendLayout()
        Me.SuspendLayout()
        '
        'radAmericano
        '
        Me.radAmericano.AutoSize = True
        Me.radAmericano.Location = New System.Drawing.Point(6, 19)
        Me.radAmericano.Name = "radAmericano"
        Me.radAmericano.Size = New System.Drawing.Size(75, 17)
        Me.radAmericano.TabIndex = 0
        Me.radAmericano.TabStop = True
        Me.radAmericano.Text = "&Americano"
        Me.radAmericano.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.radMocha)
        Me.GroupBox1.Controls.Add(Me.radLatte)
        Me.GroupBox1.Controls.Add(Me.radAmericano)
        Me.GroupBox1.Location = New System.Drawing.Point(33, 29)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(101, 97)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Drink"
        '
        'radMocha
        '
        Me.radMocha.AutoSize = True
        Me.radMocha.Location = New System.Drawing.Point(6, 65)
        Me.radMocha.Name = "radMocha"
        Me.radMocha.Size = New System.Drawing.Size(58, 17)
        Me.radMocha.TabIndex = 2
        Me.radMocha.TabStop = True
        Me.radMocha.Text = "&Mocha"
        Me.radMocha.UseVisualStyleBackColor = True
        '
        'radLatte
        '
        Me.radLatte.AutoSize = True
        Me.radLatte.Location = New System.Drawing.Point(6, 42)
        Me.radLatte.Name = "radLatte"
        Me.radLatte.Size = New System.Drawing.Size(49, 17)
        Me.radLatte.TabIndex = 1
        Me.radLatte.TabStop = True
        Me.radLatte.Text = "&Latte"
        Me.radLatte.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.radVeinti)
        Me.GroupBox2.Controls.Add(Me.radGrande)
        Me.GroupBox2.Controls.Add(Me.radTall)
        Me.GroupBox2.Location = New System.Drawing.Point(160, 29)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(101, 97)
        Me.GroupBox2.TabIndex = 2
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Size"
        '
        'radVeinti
        '
        Me.radVeinti.AutoSize = True
        Me.radVeinti.Location = New System.Drawing.Point(6, 65)
        Me.radVeinti.Name = "radVeinti"
        Me.radVeinti.Size = New System.Drawing.Size(51, 17)
        Me.radVeinti.TabIndex = 2
        Me.radVeinti.TabStop = True
        Me.radVeinti.Text = "&Veinti"
        Me.radVeinti.UseVisualStyleBackColor = True
        '
        'radGrande
        '
        Me.radGrande.AutoSize = True
        Me.radGrande.Location = New System.Drawing.Point(6, 42)
        Me.radGrande.Name = "radGrande"
        Me.radGrande.Size = New System.Drawing.Size(60, 17)
        Me.radGrande.TabIndex = 1
        Me.radGrande.TabStop = True
        Me.radGrande.Text = "&Grande"
        Me.radGrande.UseVisualStyleBackColor = True
        '
        'radTall
        '
        Me.radTall.AutoSize = True
        Me.radTall.Location = New System.Drawing.Point(6, 19)
        Me.radTall.Name = "radTall"
        Me.radTall.Size = New System.Drawing.Size(42, 17)
        Me.radTall.TabIndex = 0
        Me.radTall.TabStop = True
        Me.radTall.Text = "&Tall"
        Me.radTall.UseVisualStyleBackColor = True
        '
        'lbxMilk
        '
        Me.lbxMilk.FormattingEnabled = True
        Me.lbxMilk.Items.AddRange(New Object() {"Nonfat Milk", "2% Milk", "Whole Milk", "Soy Milk", "Almond Milk", "Rice Milk"})
        Me.lbxMilk.Location = New System.Drawing.Point(36, 143)
        Me.lbxMilk.Name = "lbxMilk"
        Me.lbxMilk.Size = New System.Drawing.Size(97, 95)
        Me.lbxMilk.TabIndex = 3
        '
        'lbExtraShots
        '
        Me.lbExtraShots.AutoSize = True
        Me.lbExtraShots.Location = New System.Drawing.Point(30, 272)
        Me.lbExtraShots.Name = "lbExtraShots"
        Me.lbExtraShots.Size = New System.Drawing.Size(61, 13)
        Me.lbExtraShots.TabIndex = 4
        Me.lbExtraShots.Text = "Extra Shots"
        '
        'cbxVanilla
        '
        Me.cbxVanilla.AutoSize = True
        Me.cbxVanilla.Location = New System.Drawing.Point(6, 19)
        Me.cbxVanilla.Name = "cbxVanilla"
        Me.cbxVanilla.Size = New System.Drawing.Size(57, 17)
        Me.cbxVanilla.TabIndex = 5
        Me.cbxVanilla.Text = "Va&nilla"
        Me.cbxVanilla.UseVisualStyleBackColor = True
        '
        'cbxAlmond
        '
        Me.cbxAlmond.AutoSize = True
        Me.cbxAlmond.Location = New System.Drawing.Point(6, 42)
        Me.cbxAlmond.Name = "cbxAlmond"
        Me.cbxAlmond.Size = New System.Drawing.Size(61, 17)
        Me.cbxAlmond.TabIndex = 6
        Me.cbxAlmond.Text = "Almon&d"
        Me.cbxAlmond.UseVisualStyleBackColor = True
        '
        'cbxCaramel
        '
        Me.cbxCaramel.AutoSize = True
        Me.cbxCaramel.Location = New System.Drawing.Point(6, 63)
        Me.cbxCaramel.Name = "cbxCaramel"
        Me.cbxCaramel.Size = New System.Drawing.Size(64, 17)
        Me.cbxCaramel.TabIndex = 7
        Me.cbxCaramel.Text = "&Caramel"
        Me.cbxCaramel.UseVisualStyleBackColor = True
        '
        'gbxFlavors
        '
        Me.gbxFlavors.Controls.Add(Me.cbxVanilla)
        Me.gbxFlavors.Controls.Add(Me.cbxCaramel)
        Me.gbxFlavors.Controls.Add(Me.cbxAlmond)
        Me.gbxFlavors.Location = New System.Drawing.Point(162, 141)
        Me.gbxFlavors.Name = "gbxFlavors"
        Me.gbxFlavors.Size = New System.Drawing.Size(99, 97)
        Me.gbxFlavors.TabIndex = 8
        Me.gbxFlavors.TabStop = False
        Me.gbxFlavors.Text = "Flavors"
        '
        'txtShots
        '
        Me.txtShots.Location = New System.Drawing.Point(97, 269)
        Me.txtShots.Name = "txtShots"
        Me.txtShots.Size = New System.Drawing.Size(28, 20)
        Me.txtShots.TabIndex = 9
        Me.txtShots.Text = "0"
        '
        'lblOrder
        '
        Me.lblOrder.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOrder.Location = New System.Drawing.Point(38, 303)
        Me.lblOrder.Name = "lblOrder"
        Me.lblOrder.Size = New System.Drawing.Size(222, 37)
        Me.lblOrder.TabIndex = 10
        Me.lblOrder.Text = "Please enter your order"
        '
        'btnOrder
        '
        Me.btnOrder.Location = New System.Drawing.Point(301, 258)
        Me.btnOrder.Name = "btnOrder"
        Me.btnOrder.Size = New System.Drawing.Size(88, 30)
        Me.btnOrder.TabIndex = 11
        Me.btnOrder.Text = "&Order"
        Me.btnOrder.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(299, 304)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(89, 35)
        Me.btnClear.TabIndex = 12
        Me.btnClear.Text = "Clea&r"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'frmOrder
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(560, 364)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnOrder)
        Me.Controls.Add(Me.lblOrder)
        Me.Controls.Add(Me.txtShots)
        Me.Controls.Add(Me.gbxFlavors)
        Me.Controls.Add(Me.lbExtraShots)
        Me.Controls.Add(Me.lbxMilk)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "frmOrder"
        Me.Text = "ESPRESSO-MATIC"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.gbxFlavors.ResumeLayout(False)
        Me.gbxFlavors.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents radAmericano As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents radMocha As System.Windows.Forms.RadioButton
    Friend WithEvents radLatte As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents radVeinti As System.Windows.Forms.RadioButton
    Friend WithEvents radGrande As System.Windows.Forms.RadioButton
    Friend WithEvents radTall As System.Windows.Forms.RadioButton
    Friend WithEvents lbxMilk As System.Windows.Forms.ListBox
    Friend WithEvents lbExtraShots As System.Windows.Forms.Label
    Friend WithEvents cbxVanilla As System.Windows.Forms.CheckBox
    Friend WithEvents cbxAlmond As System.Windows.Forms.CheckBox
    Friend WithEvents cbxCaramel As System.Windows.Forms.CheckBox
    Friend WithEvents gbxFlavors As System.Windows.Forms.GroupBox
    Friend WithEvents txtShots As System.Windows.Forms.TextBox
    Friend WithEvents lblOrder As System.Windows.Forms.Label
    Friend WithEvents btnOrder As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button

End Class
