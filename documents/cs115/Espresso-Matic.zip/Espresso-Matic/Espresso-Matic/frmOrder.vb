﻿Option Strict On
Public Class frmOrder

    Private Sub btnOrder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOrder.Click

        'Declares values for determining drink costs
        Dim decTotalCost As Decimal = 0
        Dim decDrinkCost As Decimal = 0
        Dim decSizeCost As Decimal = 0
        Dim decFlavorCost As Decimal = 0
        Dim decMilkCost As Decimal = 0
        Dim decShotCost As Decimal = 0
        Dim txtMilk As String = ""
        Dim txtSize As String = ""
        Dim txtDrink As String = ""

        'Calculates drink cost
        If radAmericano.Checked Then
            decDrinkCost = 1.5D
        ElseIf radLatte.Checked Then
            decDrinkCost = 2.5D
        ElseIf radMocha.Checked Then
            decDrinkCost = 2.5D
        End If

        'Calculates size cost
        If radGrande.Checked Then
            decSizeCost = 0.5D
        ElseIf radVeinti.Checked Then
            decSizeCost = 1
        End If

        'Calculates milk cost
        If lbxMilk.SelectedIndex <> -1 Then
            Select Case lbxMilk.SelectedItem.ToString()
                Case "Soy Milk", "Almond Milk", "Rice Milk"
                    decMilkCost = 0.5D
            End Select
        End If

        'Calculates flavor cost
        If cbxAlmond.Checked Then
            decFlavorCost += 0.35D
        End If
        If cbxCaramel.Checked Then
            decFlavorCost += 0.35D
        End If
        If cbxVanilla.Checked Then
            decFlavorCost += 0.35D
        End If

        'Calculates shot cost
        decShotCost = 0.5D * CDec(txtShots.Text)

        'Calculates total cost
        decTotalCost = decDrinkCost + decSizeCost + decMilkCost + decFlavorCost + decShotCost

        'Displays message to user
        lblOrder.Text = "Your drink costs" & decTotalCost.ToString("c")
    End Sub
End Class
