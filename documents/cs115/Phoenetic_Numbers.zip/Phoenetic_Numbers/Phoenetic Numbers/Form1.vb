﻿Public Class Form1
    Dim strResult As String = ""
    Dim strDigit As String
    Private Sub btnConvert_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConvert.Click
        Dim i As Integer
        lblNumber.Text = ""
        For i = 0 To txtNumber.Text.Length - 1
            strDigit = txtNumber.Text.Substring(i, 1)
            Select Case strDigit
                Case "0"
                    strResult = "Zero"
                Case "1"
                    strResult = "One"
                Case "2"
                    strResult = "Two"
                Case "3"
                    strResult = "Three"
                Case "4"
                    strResult = "Four"
                Case "5"
                    strResult = "Five"
                Case "6"
                    strResult = "Six"
                Case "7"
                    strResult = "Seven"
                Case "8"
                    strResult = "Eight"
                Case "9"
                    strResult = "Nine"
            End Select
            lblNumber.Text &= " " & strResult
        Next i
    End Sub
End Class
