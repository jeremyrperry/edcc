﻿'Clock
'by Jeremy Perry
'Version 1.0
'complied using MS Visual Basic studio 2008
'tested on Apple MacBook running Windows 7 via Parallels program
'CS 115 Section AA
'16 May 2010
'This program is designed to turn the current system time into a text format

Option Strict On
Public Class frmClock
    'Starts the timer
    Dim blnShowText As Boolean = False

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Timer1.Start()
        Me.Text = "Jeremy Perry, CS 115 AA, Spring 2010, " & _
        Today().ToString("d")
    End Sub

    'Loads the default setting into lblTime
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        lblTime.Text = Now().ToString("T")
        Dim strTime As String = Now().ToString("T")
        Dim strHours As String = ""
        Dim strMinutes As String = ""
        Dim strSeconds As String = ""
        Dim strAMPM As String = ""
        If strTime.Length = 10 Then
            strHours = strTime.Substring(0, 1)
            strMinutes = strTime.Substring(2, 2)
            strSeconds = strTime.Substring(5, 2)
            strAMPM = strTime.Substring(8, 2)
        ElseIf strTime.Length = 11 Then
            strHours = strTime.Substring(0, 2)
            strMinutes = strTime.Substring(3, 2)
            strSeconds = strTime.Substring(6, 2)
            strAMPM = strTime.Substring(9, 2)
        End If

        If blnShowText Then
            lblTime.Text = ConvertHours(strHours) & " " & ConvertMinutes(strMinutes) & _
            " " & strAMPM.ToString & vbCrLf & ConvertSeconds(strSeconds)
        Else
            lblTime.Text = Now().ToString("T")
        End If
    End Sub

    Private Sub btnSet_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSet.Click
        'Allows user to change lblTime's display
        If radNumbers.Checked Then
            blnShowText = False
        Else
            blnShowText = True
        End If


        If cbxColors.Text = "Dark Red" Then
            lblTime.ForeColor = Color.DarkRed
        ElseIf cbxColors.Text = "Green" Then
            lblTime.ForeColor = Color.Green
        ElseIf cbxColors.Text = "Blue" Then
            lblTime.ForeColor = Color.Blue
        ElseIf cbxColors.Text = "Black" Then
            lblTime.ForeColor = Color.Black
        ElseIf cbxColors.Text = "Purple" Then
            lblTime.ForeColor = Color.Purple
        End If

    End Sub


    Function ConvertHours(ByVal strHours As String) As String
        Select Case strHours
            Case "1"
                Return "One"
            Case "2"
                Return "Two"
            Case "3"
                Return "Three"
            Case "4"
                Return "Four"
            Case "5"
                Return "Five"
            Case "6"
                Return "Six"
            Case "7"
                Return "Seven"
            Case "8"
                Return "Eight"
            Case "9"
                Return "Nine"
            Case "10"
                Return "Ten"
            Case "11"
                Return "Eleven"
            Case "12"
                Return "Twelve"
            Case Else
                lblTime.Text = "**ERROR**"
        End Select
    End Function

    Function ConvertMinutes(ByVal strMinutes As String) As String
        Select Case strMinutes
            Case "00"
                Return "O'Clock"
            Case "01" To "09"
                Return "Oh " & ConvertMinute(strMinutes.Substring(1))
            Case "10"
                Return "Ten"
            Case "11"
                Return "Eleven"
            Case "12"
                Return "Twelve"
            Case "13"
                Return "Thirteen"
            Case "14"
                Return "Fourteen"
            Case "15"
                Return "Fifteen"
            Case "16"
                Return "Sixteen"
            Case "17"
                Return "Seventeen"
            Case "18"
                Return "Eighteen"
            Case "19"
                Return "Nineteen"
            Case "20" To "29"
                Return "Twenty " & ConvertMinute(strMinutes.Substring(1))
            Case "30" To "39"
                Return "Thirty " & ConvertMinute(strMinutes.Substring(1))
            Case "40" To "49"
                Return "Forty " & ConvertMinute(strMinutes.Substring(1))
            Case "50" To "59"
                Return "Fifty " & ConvertMinute(strMinutes.Substring(1))
            Case Else
                lblTime.Text = "**ERROR**"
        End Select
    End Function

    Function ConvertMinute(ByVal strMinutes As String) As String
        Select Case strMinutes
            Case "0"
                Return ""
            Case "1"
                Return "One"
            Case "2"
                Return "Two"
            Case "3"
                Return "Three"
            Case "4"
                Return "Four"
            Case "5"
                Return "Five"
            Case "6"
                Return "Six"
            Case "7"
                Return "Seven"
            Case "8"
                Return "Eight"
            Case "9"
                Return "Nine"
            Case Else
                lblTime.Text = "**ERROR**"
        End Select
    End Function

    Function ConvertSeconds(ByVal strSeconds As String) As String
        Select Case strSeconds
            Case "00"
                Return "Exactly"
            Case "01"
                Return "and " & ConvertSecond(strSeconds.Substring(1)) & " Second"
            Case "02" To "09"
                Return "and " & ConvertSecond(strSeconds.Substring(1)) & " Seconds"
            Case "10"
                Return "and Ten Seconds"
            Case "11"
                Return "and Eleven Seconds"
            Case "12"
                Return "and Twelve Seconds"
            Case "13"
                Return "and Thirteen Seconds"
            Case "14"
                Return "and Fourteen Seconds"
            Case "15"
                Return "and Fifteen Seconds"
            Case "16"
                Return "and Sixteen Seconds"
            Case "17"
                Return "and Seventeen Seconds"
            Case "18"
                Return "and Eighteen Seconds"
            Case "19"
                Return "and Nineteen Seconds"
            Case "20"
                Return "and Twenty Seconds"
            Case "21" To "29"
                Return "and Twenty " & ConvertSecond(strSeconds.Substring(1)) & " Seconds"
            Case "30"
                Return "and Thirty Seconds"
            Case "31" To "39"
                Return "and Thirty " & ConvertSecond(strSeconds.Substring(1)) & " Seconds"
            Case "40"
                Return "and Forty Seconds"
            Case "41" To "49"
                Return "and Forty " & ConvertSecond(strSeconds.Substring(1)) & " Seconds"
            Case "50"
                Return "and Fifty Seconds"
            Case "51" To "59"
                Return "and Fifty " & ConvertSecond(strSeconds.Substring(1)) & " Seconds"
            Case Else
                lblTime.Text = "**Error**"
        End Select
    End Function

    Function ConvertSecond(ByVal strSeconds As String) As String
        Select Case strSeconds
            Case "0"
                Return ""
            Case "1"
                Return "One"
            Case "2"
                Return "Two"
            Case "3"
                Return "Three"
            Case "4"
                Return "Four"
            Case "5"
                Return "Five"
            Case "6"
                Return "Six"
            Case "7"
                Return "Seven"
            Case "8"
                Return "Eight"
            Case "9"
                Return "Nine"
            Case Else
                lblTime.Text = "**ERROR**"
        End Select
    End Function

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class


