﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmClock
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.lblTime = New System.Windows.Forms.Label
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.radNumbers = New System.Windows.Forms.RadioButton
        Me.radText = New System.Windows.Forms.RadioButton
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.cbxColors = New System.Windows.Forms.ComboBox
        Me.btnSet = New System.Windows.Forms.Button
        Me.btnExit = New System.Windows.Forms.Button
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblTime
        '
        Me.lblTime.BackColor = System.Drawing.Color.Azure
        Me.lblTime.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTime.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTime.Location = New System.Drawing.Point(21, 211)
        Me.lblTime.Name = "lblTime"
        Me.lblTime.Size = New System.Drawing.Size(436, 88)
        Me.lblTime.TabIndex = 0
        Me.lblTime.Text = "Twelve Thirty Seven PM" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "and Thirty Seven Seconds" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.lblTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Timer1
        '
        '
        'radNumbers
        '
        Me.radNumbers.AutoSize = True
        Me.radNumbers.Location = New System.Drawing.Point(18, 22)
        Me.radNumbers.Name = "radNumbers"
        Me.radNumbers.Size = New System.Drawing.Size(67, 17)
        Me.radNumbers.TabIndex = 0
        Me.radNumbers.TabStop = True
        Me.radNumbers.Text = "&Numbers"
        Me.radNumbers.UseVisualStyleBackColor = True
        '
        'radText
        '
        Me.radText.AutoSize = True
        Me.radText.Location = New System.Drawing.Point(18, 58)
        Me.radText.Name = "radText"
        Me.radText.Size = New System.Drawing.Size(46, 17)
        Me.radText.TabIndex = 1
        Me.radText.TabStop = True
        Me.radText.Text = "&Text"
        Me.radText.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.radText)
        Me.GroupBox1.Controls.Add(Me.radNumbers)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 76)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(115, 99)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Format"
        '
        'cbxColors
        '
        Me.cbxColors.BackColor = System.Drawing.Color.Azure
        Me.cbxColors.FormattingEnabled = True
        Me.cbxColors.Items.AddRange(New Object() {"Dark Red", "Green", "Blue", "Black", "Purple"})
        Me.cbxColors.Location = New System.Drawing.Point(155, 79)
        Me.cbxColors.Name = "cbxColors"
        Me.cbxColors.Size = New System.Drawing.Size(138, 21)
        Me.cbxColors.TabIndex = 2
        Me.cbxColors.Text = "Select Display Color"
        '
        'btnSet
        '
        Me.btnSet.Location = New System.Drawing.Point(337, 79)
        Me.btnSet.Name = "btnSet"
        Me.btnSet.Size = New System.Drawing.Size(129, 36)
        Me.btnSet.TabIndex = 3
        Me.btnSet.Text = "&Set"
        Me.btnSet.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnExit.Location = New System.Drawing.Point(337, 139)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(129, 36)
        Me.btnExit.TabIndex = 4
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmClock
        '
        Me.AcceptButton = Me.btnSet
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSkyBlue
        Me.ClientSize = New System.Drawing.Size(486, 326)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnSet)
        Me.Controls.Add(Me.cbxColors)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.lblTime)
        Me.Name = "frmClock"
        Me.Text = "Jeremy Perry, CS 115 AA, Spring 2010"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lblTime As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents radNumbers As System.Windows.Forms.RadioButton
    Friend WithEvents radText As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cbxColors As System.Windows.Forms.ComboBox
    Friend WithEvents btnSet As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button

End Class
