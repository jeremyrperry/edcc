﻿Public Class frmMenu

    Dim strPrice() As String = {"4.95", "6.95", "1.75", "8.95", "3.00", "2.50"}
    Dim strDescs() As String = {"Two Eggs", "Ham && Eggs", "Bagel", "Lumberjack B'Fast", "Oatmeal", "O.J."}
    

    Private Sub frmMenu_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim lblPrice() As Label = {lblP1, lblP2, lblP3, lblP4, lblP5, lblP6}
        Dim lblDesc() As Label = {lblD1, lblD2, lblD3, lblD4, lblD5, lblD6}
        Dim txtQty() As TextBox = {txtQ1, txtQ2, txtQ3, txtQ4, txtQ5, txtQ6}
        Dim i As Integer
        For i = 0 To strPrice.Length - 1
            lblPrice(i).Text = strPrice(i)
            lblDesc(i).Text = strDescs(i)
        Next
    End Sub

    Private Sub btnTotal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTotal.Click
        Dim decTotal As Decimal = 0
        Dim decPrice As Decimal = 0
        Dim lblPrice() As Label = {lblP1, lblP2, lblP3, lblP4, lblP5, lblP6}
        Dim lblDesc() As Label = {lblD1, lblD2, lblD3, lblD4, lblD5, lblD6}
        Dim txtQty() As TextBox = {txtQ1, txtQ2, txtQ3, txtQ4, txtQ5, txtQ6}
        Dim i As Integer
        For i = 0 To strPrice.Length - 1
            If IsNumeric(txtQty(i).Text) Then
                decPrice = CDec(strPrice(i))
                decTotal += decPrice * CDec(txtQty(i).Text)
            End If
        Next
        lblTotalCost.Text = decTotal.ToString("C")
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        Dim txtQty() As TextBox = {txtQ1, txtQ2, txtQ3, txtQ4, txtQ5, txtQ6}
        Dim i As Integer
        For i = 0 To strPrice.Length - 1
            txtQty(i).Text = ""
        Next
        lblTotalCost.Text = "$0.00"
    End Sub
End Class
