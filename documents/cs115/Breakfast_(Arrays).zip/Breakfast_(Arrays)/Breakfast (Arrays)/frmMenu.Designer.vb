﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblP1 = New System.Windows.Forms.Label
        Me.txtQ1 = New System.Windows.Forms.TextBox
        Me.lblD1 = New System.Windows.Forms.Label
        Me.lblD2 = New System.Windows.Forms.Label
        Me.txtQ2 = New System.Windows.Forms.TextBox
        Me.lblP2 = New System.Windows.Forms.Label
        Me.lblD3 = New System.Windows.Forms.Label
        Me.txtQ3 = New System.Windows.Forms.TextBox
        Me.lblP3 = New System.Windows.Forms.Label
        Me.lblD5 = New System.Windows.Forms.Label
        Me.txtQ5 = New System.Windows.Forms.TextBox
        Me.lblP5 = New System.Windows.Forms.Label
        Me.lblD4 = New System.Windows.Forms.Label
        Me.txtQ4 = New System.Windows.Forms.TextBox
        Me.lblP4 = New System.Windows.Forms.Label
        Me.lblD6 = New System.Windows.Forms.Label
        Me.txtQ6 = New System.Windows.Forms.TextBox
        Me.lblP6 = New System.Windows.Forms.Label
        Me.lblTotalCost = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.btnTotal = New System.Windows.Forms.Button
        Me.btnClear = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'lblP1
        '
        Me.lblP1.AutoSize = True
        Me.lblP1.Location = New System.Drawing.Point(17, 22)
        Me.lblP1.Name = "lblP1"
        Me.lblP1.Size = New System.Drawing.Size(39, 13)
        Me.lblP1.TabIndex = 0
        Me.lblP1.Text = "Label1"
        '
        'txtQ1
        '
        Me.txtQ1.Location = New System.Drawing.Point(80, 19)
        Me.txtQ1.Name = "txtQ1"
        Me.txtQ1.Size = New System.Drawing.Size(103, 20)
        Me.txtQ1.TabIndex = 1
        '
        'lblD1
        '
        Me.lblD1.AutoSize = True
        Me.lblD1.Location = New System.Drawing.Point(221, 26)
        Me.lblD1.Name = "lblD1"
        Me.lblD1.Size = New System.Drawing.Size(39, 13)
        Me.lblD1.TabIndex = 2
        Me.lblD1.Text = "Label1"
        '
        'lblD2
        '
        Me.lblD2.AutoSize = True
        Me.lblD2.Location = New System.Drawing.Point(221, 68)
        Me.lblD2.Name = "lblD2"
        Me.lblD2.Size = New System.Drawing.Size(39, 13)
        Me.lblD2.TabIndex = 5
        Me.lblD2.Text = "Label1"
        '
        'txtQ2
        '
        Me.txtQ2.Location = New System.Drawing.Point(80, 61)
        Me.txtQ2.Name = "txtQ2"
        Me.txtQ2.Size = New System.Drawing.Size(103, 20)
        Me.txtQ2.TabIndex = 4
        '
        'lblP2
        '
        Me.lblP2.AutoSize = True
        Me.lblP2.Location = New System.Drawing.Point(17, 64)
        Me.lblP2.Name = "lblP2"
        Me.lblP2.Size = New System.Drawing.Size(39, 13)
        Me.lblP2.TabIndex = 3
        Me.lblP2.Text = "Label1"
        '
        'lblD3
        '
        Me.lblD3.AutoSize = True
        Me.lblD3.Location = New System.Drawing.Point(221, 108)
        Me.lblD3.Name = "lblD3"
        Me.lblD3.Size = New System.Drawing.Size(39, 13)
        Me.lblD3.TabIndex = 8
        Me.lblD3.Text = "Label1"
        '
        'txtQ3
        '
        Me.txtQ3.Location = New System.Drawing.Point(80, 97)
        Me.txtQ3.Name = "txtQ3"
        Me.txtQ3.Size = New System.Drawing.Size(103, 20)
        Me.txtQ3.TabIndex = 7
        '
        'lblP3
        '
        Me.lblP3.AutoSize = True
        Me.lblP3.Location = New System.Drawing.Point(17, 104)
        Me.lblP3.Name = "lblP3"
        Me.lblP3.Size = New System.Drawing.Size(39, 13)
        Me.lblP3.TabIndex = 6
        Me.lblP3.Text = "Label1"
        '
        'lblD5
        '
        Me.lblD5.AutoSize = True
        Me.lblD5.Location = New System.Drawing.Point(221, 160)
        Me.lblD5.Name = "lblD5"
        Me.lblD5.Size = New System.Drawing.Size(39, 13)
        Me.lblD5.TabIndex = 11
        Me.lblD5.Text = "Label1"
        '
        'txtQ5
        '
        Me.txtQ5.Location = New System.Drawing.Point(80, 153)
        Me.txtQ5.Name = "txtQ5"
        Me.txtQ5.Size = New System.Drawing.Size(103, 20)
        Me.txtQ5.TabIndex = 10
        '
        'lblP5
        '
        Me.lblP5.AutoSize = True
        Me.lblP5.Location = New System.Drawing.Point(17, 156)
        Me.lblP5.Name = "lblP5"
        Me.lblP5.Size = New System.Drawing.Size(39, 13)
        Me.lblP5.TabIndex = 9
        Me.lblP5.Text = "Label1"
        '
        'lblD4
        '
        Me.lblD4.AutoSize = True
        Me.lblD4.Location = New System.Drawing.Point(229, 133)
        Me.lblD4.Name = "lblD4"
        Me.lblD4.Size = New System.Drawing.Size(39, 13)
        Me.lblD4.TabIndex = 14
        Me.lblD4.Text = "Label1"
        '
        'txtQ4
        '
        Me.txtQ4.Location = New System.Drawing.Point(80, 127)
        Me.txtQ4.Name = "txtQ4"
        Me.txtQ4.Size = New System.Drawing.Size(103, 20)
        Me.txtQ4.TabIndex = 13
        '
        'lblP4
        '
        Me.lblP4.AutoSize = True
        Me.lblP4.Location = New System.Drawing.Point(25, 129)
        Me.lblP4.Name = "lblP4"
        Me.lblP4.Size = New System.Drawing.Size(39, 13)
        Me.lblP4.TabIndex = 12
        Me.lblP4.Text = "Label1"
        '
        'lblD6
        '
        Me.lblD6.AutoSize = True
        Me.lblD6.Location = New System.Drawing.Point(221, 186)
        Me.lblD6.Name = "lblD6"
        Me.lblD6.Size = New System.Drawing.Size(39, 13)
        Me.lblD6.TabIndex = 17
        Me.lblD6.Text = "Label1"
        '
        'txtQ6
        '
        Me.txtQ6.Location = New System.Drawing.Point(80, 179)
        Me.txtQ6.Name = "txtQ6"
        Me.txtQ6.Size = New System.Drawing.Size(103, 20)
        Me.txtQ6.TabIndex = 16
        '
        'lblP6
        '
        Me.lblP6.AutoSize = True
        Me.lblP6.Location = New System.Drawing.Point(17, 182)
        Me.lblP6.Name = "lblP6"
        Me.lblP6.Size = New System.Drawing.Size(39, 13)
        Me.lblP6.TabIndex = 15
        Me.lblP6.Text = "Label1"
        '
        'lblTotalCost
        '
        Me.lblTotalCost.AutoSize = True
        Me.lblTotalCost.Location = New System.Drawing.Point(80, 217)
        Me.lblTotalCost.Name = "lblTotalCost"
        Me.lblTotalCost.Size = New System.Drawing.Size(55, 13)
        Me.lblTotalCost.TabIndex = 18
        Me.lblTotalCost.Text = "Total Cost"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(79, 248)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(45, 13)
        Me.Label12.TabIndex = 19
        Me.Label12.Text = "Label12"
        '
        'btnTotal
        '
        Me.btnTotal.Location = New System.Drawing.Point(257, 237)
        Me.btnTotal.Name = "btnTotal"
        Me.btnTotal.Size = New System.Drawing.Size(88, 33)
        Me.btnTotal.TabIndex = 20
        Me.btnTotal.Text = "&Total"
        Me.btnTotal.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(257, 276)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(88, 33)
        Me.btnClear.TabIndex = 21
        Me.btnClear.Text = "&Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'frmMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(495, 372)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnTotal)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.lblTotalCost)
        Me.Controls.Add(Me.lblD6)
        Me.Controls.Add(Me.txtQ6)
        Me.Controls.Add(Me.lblP6)
        Me.Controls.Add(Me.lblD4)
        Me.Controls.Add(Me.txtQ4)
        Me.Controls.Add(Me.lblP4)
        Me.Controls.Add(Me.lblD5)
        Me.Controls.Add(Me.txtQ5)
        Me.Controls.Add(Me.lblP5)
        Me.Controls.Add(Me.lblD3)
        Me.Controls.Add(Me.txtQ3)
        Me.Controls.Add(Me.lblP3)
        Me.Controls.Add(Me.lblD2)
        Me.Controls.Add(Me.txtQ2)
        Me.Controls.Add(Me.lblP2)
        Me.Controls.Add(Me.lblD1)
        Me.Controls.Add(Me.txtQ1)
        Me.Controls.Add(Me.lblP1)
        Me.Name = "frmMenu"
        Me.Text = "Jeremy Perry, CS 115 AA, Spring 2010"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblP1 As System.Windows.Forms.Label
    Friend WithEvents txtQ1 As System.Windows.Forms.TextBox
    Friend WithEvents lblD1 As System.Windows.Forms.Label
    Friend WithEvents lblD2 As System.Windows.Forms.Label
    Friend WithEvents txtQ2 As System.Windows.Forms.TextBox
    Friend WithEvents lblP2 As System.Windows.Forms.Label
    Friend WithEvents lblD3 As System.Windows.Forms.Label
    Friend WithEvents txtQ3 As System.Windows.Forms.TextBox
    Friend WithEvents lblP3 As System.Windows.Forms.Label
    Friend WithEvents lblD5 As System.Windows.Forms.Label
    Friend WithEvents txtQ5 As System.Windows.Forms.TextBox
    Friend WithEvents lblP5 As System.Windows.Forms.Label
    Friend WithEvents lblD4 As System.Windows.Forms.Label
    Friend WithEvents txtQ4 As System.Windows.Forms.TextBox
    Friend WithEvents lblP4 As System.Windows.Forms.Label
    Friend WithEvents lblD6 As System.Windows.Forms.Label
    Friend WithEvents txtQ6 As System.Windows.Forms.TextBox
    Friend WithEvents lblP6 As System.Windows.Forms.Label
    Friend WithEvents lblTotalCost As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents btnTotal As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button

End Class
